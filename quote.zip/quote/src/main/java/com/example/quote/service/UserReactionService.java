package com.example.quote.service;

public interface UserReactionService {
    void userLikedQuote(Long quoteId);
}
